def post_slack_message(channel: str, msg: str) -> None:
    print(f"[SlackBot - {channel}]: {msg}")
