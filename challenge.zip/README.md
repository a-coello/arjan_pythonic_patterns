In order to start the application, run the `main.py` file. This will open a frame which initially will be empty.

Go to the File menu and click Open. Then, select the `shapes.json` file in order to display the shapes on the screen. The challenge is to a) implement the behavior of the Export menu item and b) improve the design of the shape parser to remove the complicated if-else statement.
