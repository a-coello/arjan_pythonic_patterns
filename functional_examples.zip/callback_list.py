from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable


@dataclass
class Button:
    label: str
    click_handlers: list[ClickHandler] = field(default_factory=list)

    def add_click_handler(self, handler: ClickHandler) -> None:
        self.click_handlers.append(handler)

    def click(self) -> None:
        print(f"Clicked on [{self.label}].")
        for handler in self.click_handlers:
            handler(self)


ClickHandler = Callable[[Button], None]


def main() -> None:
    def click_handler(button: Button) -> None:
        print(f"Handling click for button [{button.label}].")

    my_button = Button(label="Do something")
    my_button.add_click_handler(click_handler)
    my_button.add_click_handler(click_handler)
    my_button.click()


if __name__ == "__main__":
    main()
