def my_function(argument: int) -> None:
    print(f"my_function: {argument}")


def function_wrapper(another_argument: bool) -> None:
    argument = 10 if another_argument else 20
    my_function(argument)


def main() -> None:
    function_wrapper(False)


if __name__ == "__main__":
    main()
