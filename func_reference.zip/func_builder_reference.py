from typing import Callable

MyFunction = Callable[[], None]


def function_builder(argument: bool) -> MyFunction:
    def my_function() -> None:
        print(f"my_function: {argument}")

    return my_function


def main() -> None:
    my_func = function_builder(True)
    my_func()


if __name__ == "__main__":
    main()
