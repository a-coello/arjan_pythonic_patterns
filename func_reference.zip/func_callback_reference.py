from typing import Callable

Callback = Callable[[], None]


def do_something(on_complete: Callback) -> None:
    print("do_something")
    on_complete()


def main() -> None:
    def my_callback() -> None:
        print("my_callback")

    do_something(my_callback)


if __name__ == "__main__":
    main()
