In this sample implementation, I've used two design patterns to fix the problems.

The first issue to be solved is that we want to add the capability to export shapes to an SVG file and potentially we want to support other formats as well later on.

I've used the Bridge pattern with two hierarchies connected via the bridge:

1. A hierarchy of visualizations that allows us to draw shapes on different targets: a canvas, an SVG structure or anything else we like.
2. A hierarchy of shapes that each use a visualization to draw itself.

I've assumed that there are two core shape drawing tools available: drawing lines and drawing circles. Each shape then uses those tools to draw itself. To map this back to the original Bridge pattern: each shape type is a RefinedAbstraction and each visualization is a ConcreteImplementation.

The main thing that needed to be changed is that a shape doesn't directly get a Canvas object anymore, but it now gets a Visualization object (this forms the bridge). Take a look in particular at the `shape_drawing.py` file and the visualization class hierarchy to see how it works.

The second issue to be solved is that the parser is directly dependent on the shape types, leading to an ugly if-else statement that needs to be extended every time you add a new type of shape.

To solve this, I've used the Registry pattern introduced in this course extension. In this sample implementation, there's now a dictionary that maps shape types to shape parsers. Each parser is a function that returns a Shape instance. The nice thing here is that we can simply use the class initializers since the only thing we do is create an instance of a shape and pass the JSON data as an argument.

Take a look at `shape_parser.py` to see how it's been setup. If you take a look at the imports, you see that the parser is now no longer coupled to specific shape types. If you open `main.py` you see that this is where the shape imports are now, and I register them in the `main` function. This creates a single "dirty" place where everything is patched up which is what we like!

Let me know whether you came up with something completely different and how you solved these problems!
