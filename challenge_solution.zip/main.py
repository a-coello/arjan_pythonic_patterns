from tkinter import Tk

from circle import Circle
from rectangle import Rectangle
from shape_drawing import ShapeDrawing
from shape_parser import register
from star import Star


def main():
    # register the shape parsers
    register("circle", Circle)
    register("rectangle", Rectangle)
    register("star", Star)

    root = Tk()
    root.title("Shape Drawing")
    root.geometry("400x250+300+300")
    _ = ShapeDrawing(root)

    root.mainloop()


if __name__ == "__main__":
    main()
